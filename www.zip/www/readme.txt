﻿/* prof  23h 12/09/2016
- création des fichiers et des répertoires selon l'arborescence
/* prof  10h 17/09/2016  création d'un logo et installation d'un index provisoir 
                         Ajout champ "NomClasse" dans la table classe
                         création un dictionnaire de données à la racine (important pour les noms des variables) 
/* Kilian 17H 19/09/2016 Ajout de l'index a la racine du site.

/* Quentin 17H 19/09/2016 Ajout de l'index1.php dans la partie professeur.

/* Jordan 17H 19/09/2016 Création de la Base de Données et insertion de données test. 

/* Guilaume 19/09/2016 Ajout de index.php dans administrateur/AccesAbs/

/* Florent 20/09/2016 Ajout des input hidden dans les formulaires de l'index
/* ajout des colonnes 'identifiant' et 'mdp' dans les tables 'Professeur' et 'Admin'
/* prof 21h   20/09/2016 
-récup de l'index.php  
- Ajout d'une méthode selectClause qui tient compte de la clause WHERE
- test de la méthode dans le fichier controle.php