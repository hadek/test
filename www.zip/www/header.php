<?php /* 	if(!isset($_SESSION['login'])){
				header('location: ../index.php');
			}*/ ?>
<header>
	<?php include('connexion/Database.php');
	/* include(''); */
	?>
	<h1>Title</h1>
</header>