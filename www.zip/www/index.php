<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <title>QCM</title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<link rel="stylesheet" href="style.css" />
</head><body>
<div>
<?php echo (isset($_GET['mes']) && $_GET['mes']=='mdp')?'<font color="red">identifiant ou mot de passe non valide</font><br>':'';?>

<form action="controle.php" method="post">
      <fieldset>
        <legend>Professeur</legend>
          <p>
             <label for="login">Login :</label> 
            <input type="text" name="login" id="login"  />
          </p>
          <p>
            <label for="pass">Mot de passe :</label> 
            <input type="password" name="pass" id="pass" /> 
            <input type="submit" name="submit" value="Entrer" />
            <input type="hidden" name="type" value="prof">
          </p>
      </fieldset>
    </form>
 
</div>
<div>


<form action="controle.php" method="post">
      <fieldset>
        <legend>Administrateur</legend>
          <p>
             <label for="login">Login :</label> 
            <input type="text" name="login" id="login"  />
          </p>
          <p>
            <label for="pass">Mot de passe :</label> 
            <input type="password" name="pass" id="pass" /> 
            <input type="submit" name="submit" value="Entrer" />
            <input type="hidden" name="type" value="admin">
          </p>
      </fieldset>
    </form>
 
</div>
</body>
</html>
