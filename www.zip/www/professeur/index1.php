<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Espace professeur</title>
</head>

<body>

<?php include("header.php") ?>
<br>

<?php include("menu.php") ?>

<br>

Bienvenue dans l'espace professeur.
<br><br>
<a href="SaisirAbs/SaisirAbs.php">SaisirAbs</a>
<br><br>
<a href="ModifierAbs/ModifierAbs.php">ModifierAbs</a>
<br>

<?php include("footer.php") ?>

</body>
</html>